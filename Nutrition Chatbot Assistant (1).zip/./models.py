import os
import logging
from flask_sqlalchemy import SQLAlchemy

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

db = SQLAlchemy()

class ChatMessage(db.Model):
    __tablename__ = 'chat_messages'  # Match the table name in the migration
    id = db.Column(db.Integer, primary_key=True)
    message = db.Column(db.Text, nullable=False)
    is_user = db.Column(db.Boolean, nullable=False)
    timestamp = db.Column(db.DateTime, server_default=db.func.current_timestamp())

class UserProfile(db.Model):
    __tablename__ = 'user_profiles'
    id = db.Column(db.Integer, primary_key=True)
    age = db.Column(db.Integer)
    weight = db.Column(db.Float)
    height = db.Column(db.Float)
    is_vegetarian = db.Column(db.Boolean, default=False)
    is_vegan = db.Column(db.Boolean, default=False)
    is_gluten_free = db.Column(db.Boolean, default=False)
    is_non_vegetarian = db.Column(db.Boolean, default=False)
    is_halal = db.Column(db.Boolean, default=False)
    is_kosher = db.Column(db.Boolean, default=False)
    preferred_cuisine = db.Column(db.String(50))
    fitness_goal = db.Column(db.String(20))  # 'bulking', 'cutting', 'maintenance'
    activity_level = db.Column(db.String(20))  # 'sedentary', 'moderately_active', 'very_active', 'athlete'
    created_at = db.Column(db.DateTime, server_default=db.func.current_timestamp())
