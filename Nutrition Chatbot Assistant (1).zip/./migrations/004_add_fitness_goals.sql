ALTER TABLE user_profiles ADD COLUMN fitness_goal VARCHAR(20);
ALTER TABLE user_profiles ADD COLUMN activity_level VARCHAR(20);