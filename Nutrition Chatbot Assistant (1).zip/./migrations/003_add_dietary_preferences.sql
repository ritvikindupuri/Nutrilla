ALTER TABLE user_profiles ADD COLUMN is_non_vegetarian BOOLEAN DEFAULT FALSE;
ALTER TABLE user_profiles ADD COLUMN is_halal BOOLEAN DEFAULT FALSE;
ALTER TABLE user_profiles ADD COLUMN is_kosher BOOLEAN DEFAULT FALSE;
ALTER TABLE user_profiles ADD COLUMN preferred_cuisine VARCHAR(50);