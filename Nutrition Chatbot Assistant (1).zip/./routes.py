from models import UserProfile

import logging
from flask import render_template, request, jsonify
from flask import current_app as app
from models import db, ChatMessage
from abilities import llm

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def register_routes(app):
    @app.route("/")
    def home_route():
        return render_template("home.html")
    
    @app.route("/save_profile", methods=["POST"])
    def save_profile():
        try:
            data = request.get_json()
            profile = UserProfile(
                age=data.get('age'),
                weight=data.get('weight'),
                height=data.get('height'),
                is_vegetarian=data.get('is_vegetarian', False),
                is_vegan=data.get('is_vegan', False),
                is_gluten_free=data.get('is_gluten_free', False)
            )
            db.session.add(profile)
            db.session.commit()
            return jsonify({"status": "success"}), 200
        except Exception as e:
            logger.error(f"Error saving profile: {str(e)}")
            return jsonify({"error": "Failed to save profile"}), 500

    @app.route("/calculate_macros", methods=["POST"])
    def calculate_macros():
        try:
            user_profile = UserProfile.query.order_by(UserProfile.created_at.desc()).first()
            if not user_profile:
                return jsonify({"error": "Please complete your profile first"}), 400

            # Calculate BMI
            height_m = user_profile.height / 100
            bmi = user_profile.weight / (height_m * height_m)

            # Calculate base calories based on activity level
            activity_multipliers = {
                'sedentary': 1.2,
                'moderately_active': 1.5,
                'very_active': 1.7,
                'athlete': 1.9
            }
            
            # BMR using Mifflin-St Jeor Equation
            if user_profile.age:
                bmr = (10 * user_profile.weight) + (6.25 * user_profile.height) - (5 * user_profile.age)
            else:
                bmr = (10 * user_profile.weight) + (6.25 * user_profile.height)

            activity_multiplier = activity_multipliers.get(user_profile.activity_level, 1.2)
            maintenance_calories = bmr * activity_multiplier

            # Adjust calories based on fitness goal
            if user_profile.fitness_goal == 'bulking':
                target_calories = maintenance_calories * 1.15  # 15% surplus
                protein_ratio = 0.25  # 25% of calories from protein
                fat_ratio = 0.25     # 25% of calories from fat
                carb_ratio = 0.50    # 50% of calories from carbs
            elif user_profile.fitness_goal == 'cutting':
                target_calories = maintenance_calories * 0.85  # 15% deficit
                protein_ratio = 0.35  # 35% of calories from protein
                fat_ratio = 0.30     # 30% of calories from fat
                carb_ratio = 0.35    # 35% of calories from carbs
            else:  # maintenance
                target_calories = maintenance_calories
                protein_ratio = 0.30  # 30% of calories from protein
                fat_ratio = 0.30     # 30% of calories from fat
                carb_ratio = 0.40    # 40% of calories from carbs

            # Calculate macros in grams
            protein_calories = target_calories * protein_ratio
            fat_calories = target_calories * fat_ratio
            carb_calories = target_calories * carb_ratio

            protein_grams = protein_calories / 4  # 4 calories per gram of protein
            fat_grams = fat_calories / 9         # 9 calories per gram of fat
            carb_grams = carb_calories / 4       # 4 calories per gram of carbs

            return jsonify({
                "daily_calories": round(target_calories),
                "macros": {
                    "protein": {
                        "grams": round(protein_grams),
                        "calories": round(protein_calories),
                        "percentage": round(protein_ratio * 100)
                    },
                    "fats": {
                        "grams": round(fat_grams),
                        "calories": round(fat_calories),
                        "percentage": round(fat_ratio * 100)
                    },
                    "carbs": {
                        "grams": round(carb_grams),
                        "calories": round(carb_calories),
                        "percentage": round(carb_ratio * 100)
                    }
                },
                "notes": {
                    "goal": user_profile.fitness_goal,
                    "activity_level": user_profile.activity_level,
                    "bmi": round(bmi, 1)
                }
            })
        except Exception as e:
            logger.error(f"Error calculating macros: {str(e)}")
            return jsonify({"error": "Failed to calculate macros"}), 500

    @app.route("/generate_diet_plan", methods=["POST"])
    def generate_diet_plan():
        try:
            # Get the most recent user profile
            user_profile = UserProfile.query.order_by(UserProfile.created_at.desc()).first()
            if not user_profile:
                return jsonify({"error": "Please complete your profile first"}), 400

            # Define the response schema for structured diet plan
            response_schema = {
                "type": "object",
                "properties": {
                    "daily_plan": {
                        "type": "object",
                        "properties": {
                            "breakfast": {
                                "type": "object",
                                "properties": {
                                    "meals": {"type": "array", "items": {"type": "string"}},
                                    "calories": {"type": "string"},
                                    "notes": {"type": "string"}
                                }
                            },
                            "morning_snack": {
                                "type": "object",
                                "properties": {
                                    "meals": {"type": "array", "items": {"type": "string"}},
                                    "calories": {"type": "string"},
                                    "notes": {"type": "string"}
                                }
                            },
                            "lunch": {
                                "type": "object",
                                "properties": {
                                    "meals": {"type": "array", "items": {"type": "string"}},
                                    "calories": {"type": "string"},
                                    "notes": {"type": "string"}
                                }
                            },
                            "afternoon_snack": {
                                "type": "object",
                                "properties": {
                                    "meals": {"type": "array", "items": {"type": "string"}},
                                    "calories": {"type": "string"},
                                    "notes": {"type": "string"}
                                }
                            },
                            "dinner": {
                                "type": "object",
                                "properties": {
                                    "meals": {"type": "array", "items": {"type": "string"}},
                                    "calories": {"type": "string"},
                                    "notes": {"type": "string"}
                                }
                            }
                        }
                    },
                    "workout_meals": {
                        "type": "object",
                        "properties": {
                            "pre_workout": {
                                "type": "object",
                                "properties": {
                                    "meals": {"type": "array", "items": {"type": "string"}},
                                    "notes": {"type": "string"}
                                }
                            },
                            "post_workout": {
                                "type": "object",
                                "properties": {
                                    "meals": {"type": "array", "items": {"type": "string"}},
                                    "notes": {"type": "string"}
                                }
                            }
                        }
                    }
                }
            }

            # Calculate BMI
            height_m = user_profile.height / 100
            bmi = user_profile.weight / (height_m * height_m)
            
            # Build the prompt for the diet plan
            prompt = f"""Generate a detailed daily diet plan for a person with the following profile:

            Age: {user_profile.age}
            BMI: {bmi:.1f}
            Fitness Goal: {user_profile.fitness_goal}
            Activity Level: {user_profile.activity_level}
            Dietary Preferences: {', '.join(pref for pref in ['vegetarian' if user_profile.is_vegetarian else None,
                                                            'vegan' if user_profile.is_vegan else None,
                                                            'gluten-free' if user_profile.is_gluten_free else None,
                                                            'non-vegetarian' if user_profile.is_non_vegetarian else None,
                                                            'halal' if user_profile.is_halal else None,
                                                            'kosher' if user_profile.is_kosher else None] if pref)}
            Preferred Cuisine: {user_profile.preferred_cuisine}

            Create a detailed meal plan that includes:
            1. Breakfast with options and calories
            2. Morning snack with options and calories
            3. Lunch with options and calories
            4. Afternoon snack with options and calories
            5. Dinner with options and calories

            For each meal:
            - Include specific portion sizes
            - List estimated calories
            - Add helpful notes about timing or preparation
            - Ensure meals align with their fitness goal ({user_profile.fitness_goal})
            - Consider their activity level ({user_profile.activity_level})
            - Include foods from their preferred cuisine ({user_profile.preferred_cuisine})
            - Respect all dietary restrictions

            If they are active (moderate or higher activity), also include:
            - Pre-workout meal/snack suggestions
            - Post-workout meal/snack suggestions

            For bulking:
            - Focus on caloric surplus with quality proteins
            - Include protein-rich foods and complex carbs
            - Suggest larger portion sizes

            For cutting:
            - Focus on caloric deficit while maintaining protein
            - Include low-calorie, high-volume foods
            - Suggest smaller, more frequent meals

            For maintenance:
            - Balance macronutrients
            - Focus on portion control
            - Include a mix of proteins, carbs, and healthy fats"""

            try:
                result = llm(prompt=prompt, response_schema=response_schema, image_url=None, model=None, temperature=0.7)
                return jsonify(result)
            except Exception as e:
                logger.error(f"Error generating diet plan: {str(e)}")
                return jsonify({"error": "Failed to generate diet plan"}), 500

        except Exception as e:
            logger.error(f"Error in generate_diet_plan: {str(e)}")
            return jsonify({"error": "Failed to process request"}), 500

    @app.route("/chat", methods=["POST"])
    def chat():
        data = request.get_json()
        user_message = data.get("message")

        # Store user message
        db.session.add(ChatMessage(message=user_message, is_user=True))
        db.session.commit()

        # Get the most recent user profile
        user_profile = UserProfile.query.order_by(UserProfile.created_at.desc()).first()

        # Define the response schema for structured nutrition advice with bullet points
        response_schema = {
            "type": "object",
            "properties": {
                "points": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "icon": {
                                "type": "string",
                                "description": "A food-related emoji icon"
                            },
                            "text": {
                                "type": "string",
                                "description": "The content of the bullet point"
                            }
                        },
                        "required": ["icon", "text"]
                    }
                }
            },
            "required": ["points"]
        }

        # Calculate BMI and health metrics
        base_prompt = """You are a helpful nutrition assistant. Provide accurate and helpful advice about nutrition, diet, and healthy eating."""
        
        if user_profile:
            # Calculate BMI
            height_m = user_profile.height / 100  # Convert cm to meters
            bmi = user_profile.weight / (height_m * height_m)
            
            # Determine BMI category
            bmi_category = "normal weight"
            if bmi < 18.5:
                bmi_category = "underweight"
            elif bmi >= 25:
                bmi_category = "overweight"
            
            # Build dietary preferences list
            dietary_preferences = []
            if user_profile.is_vegetarian:
                dietary_preferences.append("vegetarian")
            if user_profile.is_vegan:
                dietary_preferences.append("vegan")
            if user_profile.is_gluten_free:
                dietary_preferences.append("gluten-free")
            if user_profile.is_non_vegetarian:
                dietary_preferences.append("non-vegetarian")
            if user_profile.is_halal:
                dietary_preferences.append("halal")
            if user_profile.is_kosher:
                dietary_preferences.append("kosher")
            
            base_prompt += "\nConsider the following user profile:"
            base_prompt += f"\n- Age: {user_profile.age} years"
            base_prompt += f"\n- BMI: {bmi:.1f} ({bmi_category})"
            
            if dietary_preferences:
                base_prompt += f"\n- Dietary restrictions: {', '.join(dietary_preferences)}"
            if user_profile.preferred_cuisine:
                base_prompt += f"\n- Preferred cuisine: {user_profile.preferred_cuisine}"
            
            if user_message.lower() == "hello":
                base_prompt += "\nProvide a warm, personalized greeting that acknowledges their age, BMI category, dietary preferences, and preferred cuisine. Include gentle, supportive advice based on their BMI category."

        prompt = f"""{base_prompt}

        User question: {user_message}

        Please provide a clear and concise response that is helpful and accurate. Focus on evidence-based nutrition information.
        Consider the user's age, BMI, fitness goals, and activity level when providing advice.

        For bulking goals, focus on:
        - High-protein foods for muscle growth
        - Caloric surplus with healthy foods
        - Proper meal timing around workouts
        - Protein-rich snacks

        For cutting goals, emphasize:
        - Lean protein sources
        - Low-calorie, nutrient-dense foods
        - Filling, high-fiber options
        - Healthy fat sources

        When suggesting foods, include healthy options from their preferred cuisine. For American cuisine, suggest options like:
        - Grilled chicken breast with sweet potato
        - Turkey and avocado wraps
        - Lean beef burgers with whole grain buns
        - Protein smoothies with berries and Greek yogurt
        - Egg white omelettes with vegetables
        - Tuna or salmon salads
        - Cottage cheese with fruit
        - Overnight oats with protein powder

        For vegetarians/vegans:
        - Lentils and legumes
        - Quinoa and whole grains
        - Tofu and tempeh
        - Plant-based protein shakes
        - Nuts and seeds
        - Chickpea-based dishes

        Adapt these suggestions based on:
        - Their BMI category: {bmi_category}
        - Fitness goal: {user_profile.fitness_goal}
        - Activity level: {user_profile.activity_level}
        - Dietary restrictions: {', '.join(dietary_preferences)}

        Use appropriate food emojis (🥗, 🥑, 🍎, 🥦, 🍇, 🥜, etc.) for each point."""

        try:
            result = llm(prompt=prompt, response_schema=response_schema, image_url=None, model=None, temperature=0.7)
            points = result.get("points", [])
            
            # Format response as markdown bullet points with icons
            formatted_response = "\n".join([f"* {point['icon']} {point['text']}" for point in points])
            if not formatted_response:
                formatted_response = "I apologize, but I'm having trouble generating a response. Please try again."

            # Store AI response
            db.session.add(ChatMessage(message=formatted_response, is_user=False))
            db.session.commit()
            return jsonify({"response": formatted_response})
        except Exception as e:
            logger.error(f"Error generating response: {str(e)}")
            return jsonify({"response": "I apologize, but I encountered an error. Please try again."}), 500