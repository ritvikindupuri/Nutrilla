document.addEventListener('DOMContentLoaded', () => {
    const profileModal = document.getElementById('profile-modal');
    const profileForm = document.getElementById('profile-form');
    const heightInput = document.getElementById('height');
    const weightInput = document.getElementById('weight');
    const bmiDisplay = document.getElementById('bmi-display');
    const bmiValue = document.getElementById('bmi-value');
    const bmiCategory = document.getElementById('bmi-category');
    const chatContainer = document.querySelector('.chat-container');
    const messageInput = document.getElementById('message-input');

    // Always show profile modal on page load and hide chat
    profileModal.classList.remove('hidden');
    chatContainer.style.display = 'none';
    messageInput.disabled = true;

    // Convert height from feet'inches" format to centimeters
    const convertHeightToCm = (heightStr) => {
        const match = heightStr.match(/^(\d)'(\d{1,2})?\"?$/);
        if (!match) return null;
        
        const feet = parseInt(match[1]);
        const inches = parseInt(match[2] || '0');
        const heightCm = ((feet * 12) + inches) * 2.54; // Convert to centimeters
        return heightCm;
    };

    // Calculate BMI when height or weight changes
    const calculateBMI = () => {
        const heightStr = heightInput.value.trim();
        const heightCm = convertHeightToCm(heightStr);
        const weightLbs = parseFloat(weightInput.value);

        if (heightCm && weightLbs) {
            const heightInMeters = heightCm / 100;
            const weightInKg = weightLbs * 0.45359237;
            const bmi = weightInKg / (heightInMeters * heightInMeters);
            bmiValue.textContent = bmi.toFixed(1);

            // Add weight conversion display
            const weightInKgDisplay = document.createElement('p');
            weightInKgDisplay.textContent = `Your weight: ${weightLbs} lbs (${weightInKg.toFixed(1)} kg)`;
            weightInKgDisplay.style.color = '#666';
            weightInKgDisplay.style.fontSize = '0.9rem';
            weightInKgDisplay.style.marginTop = '0.5rem';

            let category;
            if (bmi < 18.5) {
                category = 'Underweight';
            } else if (bmi < 25) {
                category = 'Normal weight';
            } else if (bmi < 30) {
                category = 'Overweight';
            } else {
                category = 'Obese';
            }

            bmiCategory.textContent = category;
            bmiDisplay.classList.remove('hidden');

            // Update or add the weight conversion display
            const existingWeightDisplay = bmiDisplay.querySelector('.weight-conversion');
            if (existingWeightDisplay) {
                existingWeightDisplay.replaceWith(weightInKgDisplay);
            } else {
                weightInKgDisplay.className = 'weight-conversion';
                bmiDisplay.insertBefore(weightInKgDisplay, bmiDisplay.querySelector('.bmi-explanation'));
            }
        } else {
            bmiDisplay.classList.add('hidden');
        }
    };

    heightInput.addEventListener('input', calculateBMI);
    weightInput.addEventListener('input', calculateBMI);

    profileForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        // Convert weight from pounds to kilograms
        const weightInPounds = parseFloat(document.getElementById('weight').value);
        const weightInKg = weightInPounds * 0.45359237;

        const formData = {
            age: parseInt(document.getElementById('age').value),
            weight: weightInKg,
            height: convertHeightToCm(document.getElementById('height').value.trim()),
            is_vegetarian: document.getElementById('is_vegetarian').checked,
            is_vegan: document.getElementById('is_vegan').checked,
            is_gluten_free: document.getElementById('is_gluten_free').checked,
            is_non_vegetarian: document.getElementById('is_non_vegetarian').checked,
            is_halal: document.getElementById('is_halal').checked,
            is_kosher: document.getElementById('is_kosher').checked,
            preferred_cuisine: document.getElementById('preferred_cuisine').value,
            fitness_goal: document.querySelector('input[name="fitness_goal"]:checked').value,
            activity_level: document.getElementById('activity_level').value
        };

        try {
            const response = await fetch('/save_profile', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(formData),
            });

            if (!response.ok) {
                throw new Error('Failed to save profile');
            }

            // Hide profile modal and show chat
            profileModal.classList.add('hidden');
            chatContainer.style.display = 'flex';
            messageInput.disabled = false;

            // Trigger initial greeting
            const chatForm = document.getElementById('chat-form');
            const messageEvent = new Event('submit');
            messageInput.value = 'hello';
            chatForm.dispatchEvent(messageEvent);
        } catch (error) {
            console.error('Error saving profile:', error);
            alert('Failed to save profile. Please try again.');
        }
    });
});