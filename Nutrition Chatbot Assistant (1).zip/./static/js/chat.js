document.addEventListener('DOMContentLoaded', () => {
    const chatForm = document.getElementById('chat-form');
    const messageInput = document.getElementById('message-input');
    const chatMessages = document.getElementById('chat-messages');
    const loadingIndicator = document.getElementById('loading-indicator');
    const generateDietPlanBtn = document.getElementById('generate-diet-plan');
    const calculateMacrosBtn = document.createElement('button');
    calculateMacrosBtn.id = 'calculate-macros';
    calculateMacrosBtn.className = 'calculate-macros-btn';
    calculateMacrosBtn.innerHTML = `
        <span>Calculate Macros</span>
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="12" r="10"></circle>
            <line x1="12" y1="8" x2="12" y2="16"></line>
            <line x1="8" y1="12" x2="16" y2="12"></line>
        </svg>
    `;
    generateDietPlanBtn.parentNode.insertBefore(calculateMacrosBtn, generateDietPlanBtn);

    const appendMessage = (message, isUser) => {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${isUser ? 'user-message' : 'ai-message'}`;

        const iconDiv = document.createElement('div');
        iconDiv.className = 'message-icon';
        iconDiv.textContent = isUser ? '👤' : '🥗';

        const contentDiv = document.createElement('div');
        contentDiv.className = 'message-content';
        
        if (isUser) {
            contentDiv.textContent = message;
        } else {
            contentDiv.innerHTML = marked.parse(message);
        }

        messageDiv.appendChild(iconDiv);
        messageDiv.appendChild(contentDiv);
        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    };

    calculateMacrosBtn.addEventListener('click', async () => {
        loadingIndicator.classList.remove('hidden');

        try {
            const response = await fetch('/calculate_macros', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                }
            });

            if (!response.ok) {
                throw new Error('Failed to calculate macros');
            }

            const data = await response.json();
            
            let formattedMacros = "# Your Daily Macro Targets\n\n";
            formattedMacros += `## Daily Calorie Target: ${data.daily_calories} calories\n\n`;
            
            formattedMacros += "## Macronutrient Breakdown\n\n";
            formattedMacros += "### Protein\n";
            formattedMacros += `* ${data.macros.protein.grams}g (${data.macros.protein.percentage}% of calories)\n`;
            formattedMacros += `* ${data.macros.protein.calories} calories from protein\n\n`;
            
            formattedMacros += "### Carbohydrates\n";
            formattedMacros += `* ${data.macros.carbs.grams}g (${data.macros.carbs.percentage}% of calories)\n`;
            formattedMacros += `* ${data.macros.carbs.calories} calories from carbs\n\n`;
            
            formattedMacros += "### Fats\n";
            formattedMacros += `* ${data.macros.fats.grams}g (${data.macros.fats.percentage}% of calories)\n`;
            formattedMacros += `* ${data.macros.fats.calories} calories from fats\n\n`;
            
            formattedMacros += "## Notes\n";
            formattedMacros += `* These targets are optimized for your ${data.notes.goal} goal\n`;
            formattedMacros += `* Based on your ${data.notes.activity_level} activity level\n`;
            formattedMacros += `* Current BMI: ${data.notes.bmi}\n`;

            appendMessage(formattedMacros, false);
        } catch (error) {
            console.error('Error:', error);
            appendMessage('Sorry, I encountered an error calculating your macros. Please try again.', false);
        } finally {
            loadingIndicator.classList.add('hidden');
        }
    });

    generateDietPlanBtn.addEventListener('click', async () => {
        // Show loading indicator
        loadingIndicator.classList.remove('hidden');

        try {
            const response = await fetch('/generate_diet_plan', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                }
            });

            if (!response.ok) {
                throw new Error('Failed to generate diet plan');
            }

            const data = await response.json();
            
            // Format the diet plan as a markdown message
            let formattedPlan = "# Your Personalized Diet Plan\n\n";
            
            // Add daily meals
            const dailyPlan = data.daily_plan;
            for (const [meal, details] of Object.entries(dailyPlan)) {
                const title = meal.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
                formattedPlan += `## ${title}\n`;
                formattedPlan += `* Suggested meals:\n${details.meals.map(m => `  - ${m}`).join('\n')}\n`;
                formattedPlan += `* Calories: ${details.calories}\n`;
                if (details.notes) {
                    formattedPlan += `* Notes: ${details.notes}\n`;
                }
                formattedPlan += '\n';
            }

            // Add workout meals if they exist
            if (data.workout_meals) {
                formattedPlan += "## Workout Nutrition\n\n";
                
                if (data.workout_meals.pre_workout) {
                    formattedPlan += "### Pre-Workout\n";
                    formattedPlan += `* Suggested options:\n${data.workout_meals.pre_workout.meals.map(m => `  - ${m}`).join('\n')}\n`;
                    if (data.workout_meals.pre_workout.notes) {
                        formattedPlan += `* Notes: ${data.workout_meals.pre_workout.notes}\n`;
                    }
                    formattedPlan += '\n';
                }

                if (data.workout_meals.post_workout) {
                    formattedPlan += "### Post-Workout\n";
                    formattedPlan += `* Suggested options:\n${data.workout_meals.post_workout.meals.map(m => `  - ${m}`).join('\n')}\n`;
                    if (data.workout_meals.post_workout.notes) {
                        formattedPlan += `* Notes: ${data.workout_meals.post_workout.notes}\n`;
                    }
                }
            }

            appendMessage(formattedPlan, false);
        } catch (error) {
            console.error('Error:', error);
            appendMessage('Sorry, I encountered an error generating your diet plan. Please try again.', false);
        } finally {
            // Hide loading indicator
            loadingIndicator.classList.add('hidden');
        }
    });

    chatForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const message = messageInput.value.trim();
        if (!message) return;

        // Clear input
        messageInput.value = '';

        // Display user message
        appendMessage(message, true);

        // Show loading indicator
        loadingIndicator.classList.remove('hidden');

        try {
            // Send message to server
            const response = await fetch('/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ message }),
            });

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

            const data = await response.json();
            appendMessage(data.response, false);
        } catch (error) {
            console.error('Error:', error);
            appendMessage('Sorry, I encountered an error. Please try again.', false);
        } finally {
            // Hide loading indicator
            loadingIndicator.classList.add('hidden');
        }
    });
});